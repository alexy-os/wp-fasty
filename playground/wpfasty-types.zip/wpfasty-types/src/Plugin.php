<?php
/**
 * WP FastY Types — data registration for declarative post-type modules.
 *
 * @package WPFasty_Types
 */

declare(strict_types=1);

namespace WPFastyTypes;

use WPFasty\Types\Field;
use WPFasty\Types\PostType;
use WPFasty\Types\Registry;

/**
 * Data side of the module system; the theme's Registry hands itself over on `wpfasty_types_loaded`.
 */
final class Plugin
{
    public function __construct(private readonly Registry $types)
    {
    }

    public static function attach(Registry $types): void
    {
        $plugin = new self($types);
        add_action('init', [$plugin, 'register']);
        add_action('init', [self::class, 'registerCurrency']);
        add_action('init', [$plugin, 'migrate'], 20);
        Codex\Rest::attach();
        if (is_admin()) {
            add_action('admin_init', [self::class, 'currencyField']);
            add_action('add_meta_boxes', [$plugin, 'metaBoxes']);
            add_action('save_post', [$plugin, 'save'], 10, 2);
            add_action('admin_init', [$plugin, 'columns']);
        }
    }

    /**
     * Store currency (ISO 4217) for `money` fields, which hold integer minor units.
     * Settings → General; REST /wp/v2/settings.
     */
    public static function registerCurrency(): void
    {
        register_setting('general', 'wpfasty_currency', [
            'type' => 'string',
            'default' => 'USD',
            'show_in_rest' => ['schema' => ['pattern' => '^[A-Z]{3}$']],
            'sanitize_callback' => [self::class, 'sanitizeCurrency'],
            'description' => __('Currency of money fields (ISO 4217 code, e.g. USD, EUR).', 'wpfasty-types'),
        ]);
    }

    public static function sanitizeCurrency(mixed $value): string
    {
        $code = strtoupper(trim(is_scalar($value) ? (string) $value : ''));
        return preg_match('/^[A-Z]{3}$/', $code) === 1 ? $code : 'USD';
    }

    public static function currencyField(): void
    {
        add_settings_field('wpfasty_currency', __('Store currency', 'wpfasty-types'), static function (): void {
            printf(
                '<input name="wpfasty_currency" id="wpfasty_currency" type="text" maxlength="3"'
                    . ' class="small-text" value="%s"> <span class="description">%s</span>',
                esc_attr((string) get_option('wpfasty_currency', 'USD')),
                esc_html__('ISO 4217 code, e.g. USD, EUR.', 'wpfasty-types')
            );
        }, 'general');
    }

    public function register(): void
    {
        foreach ($this->types->all() as $type) {
            register_post_type($type->name, $type->args());
            foreach ($type->taxonomies() as $taxonomy => $args) {
                register_taxonomy((string) $taxonomy, $type->name, (array) $args);
            }
            if ($type->fields !== []) {
                // REST exposes `meta` only for post types that support custom-fields
                // (keys are `_`-prefixed, so the core box hides them).
                add_post_type_support($type->name, 'custom-fields');
            }
            if ($type->fields !== []) {
                add_filter('rest_prepare_' . $type->name, [$this, 'restNullMeta'], 10, 2);
            }
            foreach ($type->fields as $field) {
                register_post_meta($type->name, $field->metaKey, [
                    'type' => $field->metaType(),
                    'single' => true,
                    // Typed values in REST (money = integer minor units).
                    // Opt out per field with 'show_in_rest' => false.
                    'show_in_rest' => ($field->def['show_in_rest'] ?? true) === false ? false : (
                        $field->type === 'date' ? ['schema' => ['pattern' => Field::DATE_PATTERN]] : (
                            $field->options() !== [] ? ['schema' => ['enum' => $field->options()]] : true
                        )
                    ),
                    'sanitize_callback' => [$field, 'toStorage'],
                    'auth_callback' => static fn (): bool => current_user_can('edit_posts'),
                ]);
            }
        }
    }

    /** Option holding the field types the stored meta was last normalized to: {post type: {meta key: type}}. */
    public const SCHEMA_OPTION = 'wpfasty_types_schema';
    private const TYPED = ['integer', 'number', 'money', 'boolean', 'date'];

    /**
     * Data migration when a field's declared type changes (e.g. folio `year` string → integer): every stored value
     * of that meta key is rewritten through the field's own toStorage() — "2024" → 2024 — and a value the new type
     * cannot hold is deleted ("no value", never 0, Q9). Runs once per type change; one query per changed key.
     *
     * @return array<string, int> meta key → rows rewritten or deleted
     */
    public function migrate(): array
    {
        $now = [];
        foreach ($this->types->all() as $type) {
            foreach ($type->fields as $field) {
                $now[$type->name][$field->metaKey] = $field->type;
            }
        }
        $was = (array) get_option(self::SCHEMA_OPTION, []);
        if ($was === $now) {
            return [];
        }
        global $wpdb;
        $done = [];
        foreach ($this->types->all() as $type) {
            foreach ($type->fields as $field) {
                $old = $was[$type->name][$field->metaKey] ?? null;
                if ($old === $field->type || !in_array($field->type, self::TYPED, true)) {
                    continue;
                }
                // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- one-off migration over one meta key, not cached.
                $rows = (array) $wpdb->get_results($wpdb->prepare(
                    "SELECT pm.post_id, pm.meta_value FROM {$wpdb->postmeta} pm"
                    . " INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = %s AND p.post_type = %s",
                    $field->metaKey,
                    $type->name,
                ));
                $n = 0;
                foreach ($rows as $row) {
                    $raw = (string) $row->meta_value;
                    $value = $field->type === 'date' ? Field::date($raw) : $field->toStorage($raw);
                    if ($value === null || $value === '') {
                        delete_post_meta((int) $row->post_id, $field->metaKey);
                        $n++;
                    } elseif ((string) (is_bool($value) ? (int) $value : $value) !== $raw) {
                        update_post_meta((int) $row->post_id, $field->metaKey, $value);
                        $n++;
                    }
                }
                $done[$field->metaKey] = $n;
            }
        }
        update_option(self::SCHEMA_OPTION, $now, true);
        return $done;
    }

    /**
     * REST would show a missing integer/number/boolean meta as 0/false; send null instead, so "not set"
     * (e.g. stock = unlimited) differs from 0.
     */
    public function restNullMeta(\WP_REST_Response $response, \WP_Post $post): \WP_REST_Response
    {
        $data = $response->get_data();
        $type = $this->types->get($post->post_type);
        if ($type === null || !isset($data['meta']) || !is_array($data['meta'])) {
            return $response;
        }
        foreach ($type->fields as $field) {
            $unset = !metadata_exists('post', $post->ID, $field->metaKey);
            if (array_key_exists($field->metaKey, $data['meta']) && $unset) {
                $data['meta'][$field->metaKey] = null;
            }
        }
        $response->set_data($data);
        return $response;
    }

    public function metaBoxes(string $postType): void
    {
        $type = $this->types->get($postType);
        $box = $type?->metabox();
        if ($type === null || $box === false || $type->fields === []) {
            return;
        }
        add_meta_box(
            'wpfasty-' . $type->name . '-fields',
            (string) ($box['title'] ?? __('Details', 'wpfasty-types')),
            fn (\WP_Post $post) => $this->renderMetaBox($type, $post),
            $type->name,
            (string) ($box['context'] ?? 'side'),
            (string) ($box['priority'] ?? 'default')
        );
    }

    private function renderMetaBox(PostType $type, \WP_Post $post): void
    {
        wp_nonce_field('wpfasty_save_' . $type->name, 'wpfasty_' . $type->name . '_nonce');
        foreach ($type->fields as $name => $field) {
            $value = $field->toInput(get_post_meta($post->ID, $field->metaKey, true));
            $id = 'wpfasty-' . $type->name . '-' . $name;
            $input = $field->inputType();
            if ($input === 'checkbox') {
                printf(
                    '<p><label for="%1$s"><input type="checkbox" id="%1$s"'
                        . ' name="wpfasty_fields[%2$s]" value="1"%3$s> %4$s</label></p>',
                    esc_attr($id),
                    esc_attr($name),
                    checked($value, '1', false),
                    esc_html($field->label)
                );
                continue;
            }
            if ($input === 'select') {
                $opts = '<option value=""></option>';
                foreach ($field->options() as $option) {
                    $opts .= sprintf(
                        '<option value="%1$s"%2$s>%3$s</option>',
                        esc_attr($option),
                        selected($value, $option, false),
                        esc_html((string) ($field->def['option_labels'][$option] ?? $option))
                    );
                }
                printf(
                    '<p><label for="%1$s"><strong>%2$s</strong></label><br>'
                        . '<select class="widefat" id="%1$s" name="wpfasty_fields[%3$s]">%4$s</select></p>',
                    esc_attr($id),
                    esc_html($field->label),
                    esc_attr($name),
                    $opts // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped per option above.
                );
                continue;
            }
            $step = $field->type === 'integer' ? '1' : '0.01';
            // money may be negative (Q9); integer / number stay >= 0
            $min = $field->type === 'money' ? '' : ' min="0"';
            $extra = $input === 'number' ? $min . ' step="' . esc_attr($step) . '"' : '';
            printf(
                '<p><label for="%1$s"><strong>%2$s</strong></label><br>'
                    . '<input class="widefat" type="%3$s"%4$s id="%1$s" name="wpfasty_fields[%5$s]" value="%6$s"></p>',
                esc_attr($id),
                esc_html($field->label),
                esc_attr($input),
                $extra, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_attr above.
                esc_attr($name),
                esc_attr($value)
            );
        }
    }

    public function save(int $postId, \WP_Post $post): void
    {
        $type = $this->types->get($post->post_type);
        if ($type === null || $type->fields === [] || $type->metabox() === false) {
            return;
        }
        $key = 'wpfasty_' . $type->name . '_nonce';
        $nonce = isset($_POST[$key]) ? sanitize_text_field(wp_unslash($_POST[$key])) : '';
        if (!wp_verify_nonce($nonce, 'wpfasty_save_' . $type->name)
            || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            || !current_user_can('edit_post', $postId)
        ) {
            return;
        }
        // Each value is sanitized per field type below.
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $input = isset($_POST['wpfasty_fields']) && is_array($_POST['wpfasty_fields'])
            ? wp_unslash($_POST['wpfasty_fields'])
            : [];
        foreach ($type->fields as $name => $field) {
            $value = $field->fromInput($input[$name] ?? '');
            if ($value === null) {
                delete_post_meta($postId, $field->metaKey);
            } else {
                update_post_meta($postId, $field->metaKey, $value);
            }
        }
    }

    /** Admin list columns: module `columns` => [key => ['label' => string, 'value' => callable(int): string]]. */
    public function columns(): void
    {
        foreach ($this->types->all() as $type) {
            $columns = (array) ($type->def['columns'] ?? []);
            if ($columns === []) {
                continue;
            }
            add_filter('manage_' . $type->name . '_posts_columns', static function (array $c) use ($columns): array {
                $extra = [];
                foreach ($columns as $key => $col) {
                    $extra[(string) $key] = (string) ($col['label'] ?? $key);
                }
                return array_slice($c, 0, 2, true) + $extra + $c;
            });
            $hook = 'manage_' . $type->name . '_posts_custom_column';
            add_action($hook, static function (string $col, int $id) use ($columns): void {
                if (isset($columns[$col]['value']) && is_callable($columns[$col]['value'])) {
                    echo esc_html((string) $columns[$col]['value']($id));
                }
            }, 10, 2);
        }
    }
}
